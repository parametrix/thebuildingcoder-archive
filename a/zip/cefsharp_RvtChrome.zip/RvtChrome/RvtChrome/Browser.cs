﻿using CefSharp;
using CefSharp.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RvtChrome
{
  public partial class Browser : Form
  {
    WebView _webView;

    public Browser()
    {
      InitializeComponent();
    }

    private void Browser_Load( object sender, EventArgs e )
    {
      _webView = new WebView( "http://www.google.com", new BrowserSettings() );
      _webView.PropertyChanged += OnPropertyChanged; // += new PropertyChangedEventHandler( _webView_PropertyChanged );
      _webView.Dock = DockStyle.Fill;
      this.Controls.Add( _webView );
    }

    void OnPropertyChanged( 
      object sender, 
      PropertyChangedEventArgs e )
    {
      // Get all properties from https://github.com/chillitom/CefSharp/blob/master/CefSharp/BrowserCore.h

      BrowserCore core = (BrowserCore) sender;

      switch( e.PropertyName )
      {
        case "IsBrowserInitialized":
          //core.IsBrowserInitialized
          break;
        case "Title":
          //core.Title
          break;
        case "Address":
          //core.Address
          break;
        case "CanGoBack":
          //core.CanGoBack
          break;
        case "CanGoForward":
          //core.CanGoForward;
          break;
        case "IsLoading":
          //core.IsLoading
          break;
      }
    }
  }
}
