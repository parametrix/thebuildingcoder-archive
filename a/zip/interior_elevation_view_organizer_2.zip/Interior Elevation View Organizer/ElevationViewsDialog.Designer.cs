﻿namespace ZGF.Revit
{
    partial class ElevationViewsDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewsAll = new System.Windows.Forms.DataGridView();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelVersion = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelViewCount = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelProgress = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.checkBoxLevel = new System.Windows.Forms.CheckBox();
            this.CheckboxViewType = new System.Windows.Forms.CheckBox();
            this.textBoxSearchTerms = new System.Windows.Forms.TextBox();
            this.buttonClearSearch = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemSetValue = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemClear = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItemTitleEqualName = new System.Windows.Forms.ToolStripMenuItem();
            this.colViewName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNewViewName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTitleOnSheet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colViewType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLevel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNotes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEditedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEditable = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsAll)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewsAll
            // 
            this.dataGridViewsAll.AllowUserToAddRows = false;
            this.dataGridViewsAll.AllowUserToDeleteRows = false;
            this.dataGridViewsAll.AllowUserToResizeRows = false;
            this.dataGridViewsAll.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewsAll.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewsAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewsAll.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colViewName,
            this.colNewViewName,
            this.colTitleOnSheet,
            this.colViewType,
            this.colLevel,
            this.colNotes,
            this.colEditedBy,
            this.colEditable});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewsAll.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewsAll.Location = new System.Drawing.Point(4, 6);
            this.dataGridViewsAll.Name = "dataGridViewsAll";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewsAll.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewsAll.RowHeadersVisible = false;
            this.dataGridViewsAll.Size = new System.Drawing.Size(608, 319);
            this.dataGridViewsAll.TabIndex = 0;
            this.dataGridViewsAll.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewsAll_CellMouseClick);
            // 
            // buttonOK
            // 
            this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOK.Enabled = false;
            this.buttonOK.Location = new System.Drawing.Point(471, 332);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(66, 25);
            this.buttonOK.TabIndex = 1;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(543, 332);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(66, 25);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.AutoSize = false;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelVersion,
            this.toolStripStatusLabelViewCount,
            this.toolStripStatusLabelProgress,
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 364);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(617, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelVersion
            // 
            this.toolStripStatusLabelVersion.AutoSize = false;
            this.toolStripStatusLabelVersion.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabelVersion.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.toolStripStatusLabelVersion.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabelVersion.Name = "toolStripStatusLabelVersion";
            this.toolStripStatusLabelVersion.Size = new System.Drawing.Size(150, 17);
            this.toolStripStatusLabelVersion.Text = "toolStripStatusLabel1";
            this.toolStripStatusLabelVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelViewCount
            // 
            this.toolStripStatusLabelViewCount.AutoSize = false;
            this.toolStripStatusLabelViewCount.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabelViewCount.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.toolStripStatusLabelViewCount.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabelViewCount.Name = "toolStripStatusLabelViewCount";
            this.toolStripStatusLabelViewCount.Size = new System.Drawing.Size(150, 17);
            this.toolStripStatusLabelViewCount.Text = "toolStripStatusLabel2";
            this.toolStripStatusLabelViewCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelProgress
            // 
            this.toolStripStatusLabelProgress.AutoSize = false;
            this.toolStripStatusLabelProgress.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabelProgress.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.toolStripStatusLabelProgress.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabelProgress.Name = "toolStripStatusLabelProgress";
            this.toolStripStatusLabelProgress.Size = new System.Drawing.Size(150, 17);
            this.toolStripStatusLabelProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(150, 16);
            // 
            // checkBoxLevel
            // 
            this.checkBoxLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxLevel.AutoSize = true;
            this.checkBoxLevel.Location = new System.Drawing.Point(320, 337);
            this.checkBoxLevel.Name = "checkBoxLevel";
            this.checkBoxLevel.Size = new System.Drawing.Size(52, 17);
            this.checkBoxLevel.TabIndex = 0;
            this.checkBoxLevel.Text = "Level";
            this.checkBoxLevel.UseVisualStyleBackColor = true;
            this.checkBoxLevel.CheckedChanged += new System.EventHandler(this.checkBoxLevel_CheckedChanged);
            // 
            // CheckboxViewType
            // 
            this.CheckboxViewType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.CheckboxViewType.AutoSize = true;
            this.CheckboxViewType.Location = new System.Drawing.Point(241, 337);
            this.CheckboxViewType.Name = "CheckboxViewType";
            this.CheckboxViewType.Size = new System.Drawing.Size(73, 17);
            this.CheckboxViewType.TabIndex = 0;
            this.CheckboxViewType.Text = "ViewType";
            this.CheckboxViewType.UseVisualStyleBackColor = true;
            this.CheckboxViewType.CheckedChanged += new System.EventHandler(this.CheckboxViewType_CheckedChanged);
            // 
            // textBoxSearchTerms
            // 
            this.textBoxSearchTerms.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxSearchTerms.Location = new System.Drawing.Point(5, 334);
            this.textBoxSearchTerms.Name = "textBoxSearchTerms";
            this.textBoxSearchTerms.Size = new System.Drawing.Size(198, 20);
            this.textBoxSearchTerms.TabIndex = 2;
            this.textBoxSearchTerms.TextChanged += new System.EventHandler(this.textBoxSearchTerms_TextChanged);
            // 
            // buttonClearSearch
            // 
            this.buttonClearSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonClearSearch.BackgroundImage = global::ZGF.Revit.Properties.Resources.Clear_Search;
            this.buttonClearSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonClearSearch.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.buttonClearSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClearSearch.Location = new System.Drawing.Point(207, 335);
            this.buttonClearSearch.Name = "buttonClearSearch";
            this.buttonClearSearch.Size = new System.Drawing.Size(17, 18);
            this.buttonClearSearch.TabIndex = 7;
            this.buttonClearSearch.TabStop = false;
            this.buttonClearSearch.Text = "...";
            this.buttonClearSearch.UseVisualStyleBackColor = true;
            this.buttonClearSearch.Click += new System.EventHandler(this.buttonSearchTerms_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemSetValue,
            this.toolStripMenuItemClear,
            this.toolStripSeparator2,
            this.toolStripMenuItemTitleEqualName});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(207, 76);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // toolStripMenuItemSetValue
            // 
            this.toolStripMenuItemSetValue.Name = "toolStripMenuItemSetValue";
            this.toolStripMenuItemSetValue.Size = new System.Drawing.Size(206, 22);
            this.toolStripMenuItemSetValue.Text = "Apply to selected";
            this.toolStripMenuItemSetValue.Click += new System.EventHandler(this.toolStripMenuItemSetValue_Click);
            // 
            // toolStripMenuItemClear
            // 
            this.toolStripMenuItemClear.Name = "toolStripMenuItemClear";
            this.toolStripMenuItemClear.Size = new System.Drawing.Size(206, 22);
            this.toolStripMenuItemClear.Text = "Clear";
            this.toolStripMenuItemClear.Click += new System.EventHandler(this.toolStripMenuItemClear_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(203, 6);
            // 
            // toolStripMenuItemTitleEqualName
            // 
            this.toolStripMenuItemTitleEqualName.Name = "toolStripMenuItemTitleEqualName";
            this.toolStripMenuItemTitleEqualName.Size = new System.Drawing.Size(206, 22);
            this.toolStripMenuItemTitleEqualName.Text = "Title on Sheet = View Name";
            this.toolStripMenuItemTitleEqualName.Click += new System.EventHandler(this.toolStripMenuItemTitleEqualName_Click);
            // 
            // colViewName
            // 
            this.colViewName.DataPropertyName = "ViewName";
            this.colViewName.HeaderText = "Current View Name";
            this.colViewName.Name = "colViewName";
            this.colViewName.ReadOnly = true;
            // 
            // colNewViewName
            // 
            this.colNewViewName.DataPropertyName = "NewViewName";
            this.colNewViewName.HeaderText = "New View Name";
            this.colNewViewName.Name = "colNewViewName";
            this.colNewViewName.ReadOnly = true;
            // 
            // colTitleOnSheet
            // 
            this.colTitleOnSheet.DataPropertyName = "TitleOnSheet";
            this.colTitleOnSheet.HeaderText = "Title on Sheet";
            this.colTitleOnSheet.Name = "colTitleOnSheet";
            // 
            // colViewType
            // 
            this.colViewType.DataPropertyName = "ViewType";
            this.colViewType.HeaderText = "ViewType";
            this.colViewType.Name = "colViewType";
            this.colViewType.ReadOnly = true;
            // 
            // colLevel
            // 
            this.colLevel.DataPropertyName = "LevelName";
            this.colLevel.HeaderText = "Level";
            this.colLevel.Name = "colLevel";
            this.colLevel.ReadOnly = true;
            // 
            // colNotes
            // 
            this.colNotes.DataPropertyName = "Remarks";
            this.colNotes.HeaderText = "Remarks";
            this.colNotes.Name = "colNotes";
            this.colNotes.ReadOnly = true;
            // 
            // colEditedBy
            // 
            this.colEditedBy.DataPropertyName = "EditedBy";
            this.colEditedBy.HeaderText = "Edited by";
            this.colEditedBy.Name = "colEditedBy";
            this.colEditedBy.ReadOnly = true;
            // 
            // colEditable
            // 
            this.colEditable.DataPropertyName = "Editable";
            this.colEditable.HeaderText = "Editable";
            this.colEditable.Name = "colEditable";
            this.colEditable.ReadOnly = true;
            this.colEditable.Width = 25;
            // 
            // ElevationViewsDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(617, 386);
            this.Controls.Add(this.CheckboxViewType);
            this.Controls.Add(this.checkBoxLevel);
            this.Controls.Add(this.buttonClearSearch);
            this.Controls.Add(this.textBoxSearchTerms);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.dataGridViewsAll);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(625, 240);
            this.Name = "ElevationViewsDialog";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ElevationViewsDialog";
            this.SizeChanged += new System.EventHandler(this.ElevationViewsDialog_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsAll)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewsAll;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelVersion;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelViewCount;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.CheckBox checkBoxLevel;
        private System.Windows.Forms.CheckBox CheckboxViewType;
        private System.Windows.Forms.TextBox textBoxSearchTerms;
        private System.Windows.Forms.Button buttonClearSearch;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelProgress;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemClear;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemTitleEqualName;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemSetValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colViewName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNewViewName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTitleOnSheet;
        private System.Windows.Forms.DataGridViewTextBoxColumn colViewType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLevel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNotes;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEditedBy;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEditable;
    }
}