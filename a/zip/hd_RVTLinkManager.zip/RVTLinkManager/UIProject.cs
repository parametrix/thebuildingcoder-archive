﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Diagnostics;

namespace RevitFileData
{
    public partial class UIProject : System.Windows.Forms.Form
    {


        public UIProject(string filename)
        {
            InitializeComponent();

            RevitProjectRaw raw = new RevitFileData.RevitProjectRaw();
            ProjectData pd = raw.GetRevitBasicFileInfo(filename);
            propertyGrid1.SelectedObject = pd;

        }

    }


    [DefaultPropertyAttribute("IsWorkshared")]
    public class ProjectData
    {
        private bool isWorkshared = true;
        private bool isCentral = true;
        private string centralPath = string.Empty;
        private bool isLocal = true;
        private bool isCreatedLocal = true;
        private bool allLocalChangesSavedToCentral = true;
        private string savedInVersion = string.Empty;
        private string userName = string.Empty;
        private DateTime lastSaved;
        private string fileName = string.Empty;

        [DescriptionAttribute("Indicates if the file is workshared"),
        CategoryAttribute("Worksharing"),
        ReadOnlyAttribute(true),
        DefaultValueAttribute(true)]
        public bool IsWorkshared
        {
            get { return isWorkshared; }
            set { isWorkshared = value; }
        }

        [DescriptionAttribute("Indicates if this is a central file"),
        CategoryAttribute("Worksharing"),
        ReadOnlyAttribute(true),
        DefaultValueAttribute(true)]
        public bool IsCentral
        {
            get { return isCentral; }
            set { isCentral = value; }
        }

        [DescriptionAttribute("The path to the central file"),
     CategoryAttribute("Worksharing"),
     ReadOnlyAttribute(true),
     DefaultValueAttribute("")]
        public string CentralPath
        {
            get { return centralPath; }
            set { centralPath = value; }
        }

        [DescriptionAttribute("Indicates if this is a local file"),
       CategoryAttribute("Worksharing"),
       ReadOnlyAttribute(true),
       DefaultValueAttribute(true)]
        public bool IsLocal
        {
            get { return isLocal; }
            set { isLocal = value; }
        }

        [DescriptionAttribute("Indicates if this is created local"),
        CategoryAttribute("Worksharing"),
        ReadOnlyAttribute(true),
        DefaultValueAttribute(true)]
        public bool IsCreatedLocal
        {
            get { return isCreatedLocal; }
            set { isCreatedLocal = value; }
        }

        [DescriptionAttribute("The local username for the file"),
        CategoryAttribute("Worksharing"),
        ReadOnlyAttribute(true),
        DefaultValueAttribute("")]
        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        [DescriptionAttribute("Indicates if the central file contains all local changes"),
     CategoryAttribute("Worksharing"),
     ReadOnlyAttribute(true),
     DefaultValueAttribute(true)]
        public bool AllLocalChangesSavedToCentral
        {
            get { return allLocalChangesSavedToCentral; }
            set { allLocalChangesSavedToCentral = value; }
        }

        [DescriptionAttribute("The Revit version this file is saved in"),
        CategoryAttribute("Document"),
        ReadOnlyAttribute(true),
        DefaultValueAttribute("")]
        public string SavedInVersion
        {
            get { return savedInVersion; }
            set { savedInVersion = value; }
        }

        [DescriptionAttribute("When the file was last saved"),
      CategoryAttribute("Document"),
      ReadOnlyAttribute(true)]
        //DefaultValueAttribute("")]
        public DateTime LastSaved
        {
            get { return lastSaved; }
            set { lastSaved = value; }
        }

        [DescriptionAttribute("Name of the selected file"),
     CategoryAttribute("Document"),
     ReadOnlyAttribute(true),
     DefaultValueAttribute("")]
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }


    }


}
