﻿namespace RevitFileData
{
    partial class UIFamily
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewFamilys = new System.Windows.Forms.DataGridView();
            this.dataGridViewTypes = new System.Windows.Forms.DataGridView();
            this.dataGridViewProps = new System.Windows.Forms.DataGridView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFamilys)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTypes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProps)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewFamilys
            // 
            this.dataGridViewFamilys.AllowUserToAddRows = false;
            this.dataGridViewFamilys.AllowUserToDeleteRows = false;
            this.dataGridViewFamilys.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewFamilys.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewFamilys.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFamilys.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewFamilys.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewFamilys.MultiSelect = false;
            this.dataGridViewFamilys.Name = "dataGridViewFamilys";
            this.dataGridViewFamilys.ReadOnly = true;
            this.dataGridViewFamilys.RowHeadersVisible = false;
            this.dataGridViewFamilys.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewFamilys.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewFamilys.Size = new System.Drawing.Size(576, 207);
            this.dataGridViewFamilys.TabIndex = 1;
            this.dataGridViewFamilys.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewFamilys_CellClick);
            // 
            // dataGridViewTypes
            // 
            this.dataGridViewTypes.AllowUserToAddRows = false;
            this.dataGridViewTypes.AllowUserToDeleteRows = false;
            this.dataGridViewTypes.AllowUserToResizeRows = false;
            this.dataGridViewTypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewTypes.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewTypes.MultiSelect = false;
            this.dataGridViewTypes.Name = "dataGridViewTypes";
            this.dataGridViewTypes.ReadOnly = true;
            this.dataGridViewTypes.RowHeadersVisible = false;
            this.dataGridViewTypes.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewTypes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTypes.Size = new System.Drawing.Size(226, 284);
            this.dataGridViewTypes.TabIndex = 2;
            this.dataGridViewTypes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewFamType_CellClick);
            // 
            // dataGridViewProps
            // 
            this.dataGridViewProps.AllowUserToResizeRows = false;
            this.dataGridViewProps.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewProps.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewProps.Name = "dataGridViewProps";
            this.dataGridViewProps.ReadOnly = true;
            this.dataGridViewProps.RowHeadersVisible = false;
            this.dataGridViewProps.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewProps.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProps.Size = new System.Drawing.Size(346, 284);
            this.dataGridViewProps.TabIndex = 4;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(13, 13);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridViewFamilys);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(576, 495);
            this.splitContainer1.SplitterDistance = 207;
            this.splitContainer1.TabIndex = 5;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dataGridViewTypes);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dataGridViewProps);
            this.splitContainer2.Size = new System.Drawing.Size(576, 284);
            this.splitContainer2.SplitterDistance = 226;
            this.splitContainer2.TabIndex = 0;
            // 
            // UIFamily
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 526);
            this.Controls.Add(this.splitContainer1);
            this.Name = "UIFamily";
            this.Text = "UIProps";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFamilys)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTypes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProps)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridViewFamilys;
        private System.Windows.Forms.DataGridView dataGridViewTypes;
        private System.Windows.Forms.DataGridView dataGridViewProps;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
    }
}