﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;

namespace RevitFileData
{
    class RevitFamilyRaw
    {


        public xFamilyCore TheFamily
        {
            get; set;
        }


        /// <summary>
        /// The Constructor
        /// </summary>
        /// <param name="file"></param>
        public RevitFamilyRaw(string file)
        {
            GetFamilyXMLData(file);
        }


        #region Methods

        /// <summary>
        /// Get XML data from the family
        /// </summary>
        /// <param name="file"></param>
        /// The path to the family
        /// <returns></returns>
        private void GetFamilyXMLData(string file)
        {
           

            XmlDocument doc = new XmlDocument();
            string xml_meta = string.Empty;
            try
            {
                xml_meta = GetXMLString(file);
                xml_meta = xml_meta.Replace("\r", "").Replace("\n", "");
            }
            catch
            {
                Debug.Print("Cannot read XML data: " + file);
                return;
            }

            try
            {
                doc.LoadXml(xml_meta);
            }
            catch
            {
                Debug.Print("Cannot load XML data: " + file);
                return;
            }

            //XmlNodeList id = doc.GetElementsByTagName("id");
            //XmlNodeList tax = doc.GetElementsByTagName("A:taxonomy");
            //XmlNodeList link = doc.GetElementsByTagName("A:link");
            //XmlNodeList feat = doc.GetElementsByTagName("A:features");
            //XmlNodeList fam = doc.GetElementsByTagName("A:family");
            //XmlNodeList cat = doc.GetElementsByTagName("category");


            TheFamily = new xFamilyCore();

            //XML data within familys can vary slightly in where a certain property is found
            //For example category are sometimes found below "A:taxonomy"
            //Its probably consistent on newer familys
            //This code does not take that into account
            //There is also more extractable info we could have used such as hosting behaviour

            XmlNodeList version = doc.GetElementsByTagName("A:product-version");
            if (version.Count > 0)
                TheFamily.Version = version.Item(0).InnerXml;

            foreach(XmlNode entryNodes in doc.ChildNodes)
            {
                foreach(XmlNode xn in entryNodes)
                {
                    if(xn.Name == "title")
                        TheFamily.Family = xn.InnerText;
                    if (xn.Name == "category")
                    {
                        TheFamily.Category = xn.FirstChild.InnerXml;
                    }
                }
            }

            TheFamily.idFamily = Guid.NewGuid();

            XmlNodeList familyTypes = doc.GetElementsByTagName("A:part");
            List<xType> types = new List<xType>();
            foreach(XmlNode xn in familyTypes)
            {
                xType TheType = new xType();
                TheType.idFamily = TheFamily.idFamily;
                TheType.idType = Guid.NewGuid();
                XmlNode node = xn.FirstChild;
                TheType.Type = node.InnerXml;

                TheType.properties = new List<xProperty>();
                
                foreach (XmlNode parameter in xn.ChildNodes)
                {
                    if (parameter.InnerText == "title")
                        continue;

                    xProperty prop = new RevitFileData.xProperty();
                    prop.idType = TheType.idType;
                    prop.Parameter = parameter.Name;
                    prop.Value = parameter.InnerText;
                  
                    TheType.properties.Add(prop);
                }

                types.Add(TheType);
            }

            TheFamily.Types = types;

        }


        private string GetXMLString(string file)
        {
            byte[] array = File.ReadAllBytes(file);

            string string_file = Encoding.UTF8.GetString(array);
            int start = string_file.IndexOf("<entry");
            if (start == -1)
            {
                Debug.Print("XML start not detected: " + file);
                return null;
            }

            int end = string_file.IndexOf("/entry>");
            if (end == -1)
            {
                Debug.Print("XML end not detected: " + file);
                //has start but no end, do bytes for valid data

                return null;
            }

            end = end + 7;

            int length = end - start;
            if (length <= 0)
            {
                Debug.Print("XML length is 0 or less: " + file);
                return null;
            }

            return string_file.Substring(start, length);

        }

        #endregion Methods

    }

    #region Family DataStructure

    /// <summary>
    /// The Family
    /// </summary>
    class xFamilyCore : IEnumerable<xFamilyCore>
    {

        public Guid idFamily
        {
            get; set;
        }

        [DisplayName("Family")]
        public string Family
        {
            get; set;
        }

        [DisplayName("Category")]
        public string Category
        {
            get; set;
        }

        [DisplayName("Version")]
        public string Version
        {
            get; set;
        }

        [DisplayName("Types")]
        public List<xType> Types
        {
            get; set;
        }


        public xFamilyCore()
        {
            Family = string.Empty;
            Category = string.Empty;
            Version = string.Empty;
            idFamily = new Guid();
            Types = new List<RevitFileData.xType>();
        }

        public IEnumerator<xFamilyCore> GetEnumerator()
        {
            throw new NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// The types within the family
    /// </summary>
    class xType
    {

        //the id of the family it belongs to
        public Guid idFamily
        {
            get; set;
        }

        public Guid idType
        {
            get; set;
        }

        [DisplayName("Type")]
        public string Type
        {
            get; set;
        }

        [DisplayName("Parameters")]
        public List<xProperty> properties
        {
            get; set;
        }

      

        public xType()
        {
            idType = new Guid();
            idFamily = new Guid();
            Type = string.Empty;
            properties = new List<RevitFileData.xProperty>();
            
            
        }

    }

    /// <summary>
    /// The properties within the type
    /// </summary>
    class xProperty
    {

        //the id if the type the parameters belongs to
        public Guid idType
        {
            get; set;
        }

        [DisplayName("Parameter")]
        public string Parameter
        {
            get; set;
        }

        [DisplayName("Value")]
        public string Value
        {
            get; set;
        }

        //[DisplayName("ParameterType")]
        //public string ParameterType
        //{
        //    get; set;
        //}

        public xProperty()
        {
            idType = new Guid();
            Parameter = string.Empty;
            Value = string.Empty;
            //ParameterType = string.Empty;
           

        }

    }

    #endregion Family DataStructure

}

