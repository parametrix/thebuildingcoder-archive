﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevitFileData
{


    class Program
    {

        [STAThread]
        static void Main(string[] args)
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //string exePath = Assembly.GetExecutingAssembly().Location + " %1";
            //AddMenuToRegistry("folder", "rvt_rightclick_info", "Revit Data", exePath);
            //AddMenuToRegistry(".rvt", "rvt_rightclick_info", "Revit Data", exePath);
            //AddMenuToRegistry(".rfa", "rvt_rightclick_info", "Revit Data", exePath);

            string path = (1 == args.Length) ? args[0] : string.Empty;

            if (args.Count() > 1) //usually when paths contain spaces
            {
                path = string.Join(" ", args); //shaky
            }

            if (File.Exists(path) || Directory.Exists(path))
            {

                if (path.EndsWith(".rvt", StringComparison.InvariantCultureIgnoreCase))
                    Application.Run(new UIProject(path));
                else
                    Application.Run(new UIFamily(path));

            }
        }


        /// <summary>
        /// Add rightclick menu to registry
        /// Call AddContextMenuItem() + " %1"
        /// </summary>
        /// <param name="file_extension"></param>
        /// <param name="menu_name"></param>
        /// <param name="display_name"></param>
        /// <param name="path_exe"></param>
        /// <returns></returns>
        private static bool AddMenuToRegistry(string file_extension, string menu_name, string display_name, string path_exe)
        {
            bool ret = false;
            RegistryKey rkey = Registry.ClassesRoot.OpenSubKey(file_extension);
            if (rkey != null)
            {
                string extstring = rkey.GetValue("").ToString();
                rkey.Close();
                if (extstring != null)
                {
                    if (extstring.Length > 0)
                    {
                        rkey = Registry.ClassesRoot.OpenSubKey(extstring, true);
                        if (rkey != null)
                        {
                            string strkey = "shell\\" + menu_name + "\\command";
                            RegistryKey subky = rkey.CreateSubKey(strkey);
                            if (subky != null)
                            {
                                subky.SetValue("", path_exe);
                                subky.Close();
                                subky = rkey.OpenSubKey("shell\\" + menu_name, true);
                                if (subky != null)
                                {
                                    subky.SetValue("", display_name);
                                    subky.Close();
                                }
                                ret = true;
                            }
                            rkey.Close();
                        }
                    }
                }
            }
            return ret;
        }


    }

}
