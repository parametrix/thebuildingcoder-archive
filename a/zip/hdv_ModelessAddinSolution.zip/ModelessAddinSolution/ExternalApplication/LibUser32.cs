﻿//------------------------------------------------------------------------------
//
// © 2008-2017 Ideate, Inc.
//
//------------------------------------------------------------------------------

using System.Runtime.InteropServices;
using System.Text;
using HWND = System.IntPtr;

namespace Ideate.ModelessAddinSolution.ExternalApplication
{
    internal class LibUser32
    {
        // User32 Dll calls used
        [DllImport("USER32.DLL")] internal static extern int GetWindowText(HWND hWnd, StringBuilder lpString, int nMaxCount);
        [DllImport("USER32.DLL")] internal static extern int GetWindowTextLength(HWND hWnd);
        [DllImport("USER32.DLL")] internal static extern bool SetForegroundWindow(HWND hWnd);
    }
}
