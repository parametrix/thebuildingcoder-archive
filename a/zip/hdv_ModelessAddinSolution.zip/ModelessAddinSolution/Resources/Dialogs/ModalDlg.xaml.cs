﻿//------------------------------------------------------------------------------
//
// © 2008-2017 Ideate, Inc.
//
//------------------------------------------------------------------------------

using System.Windows;

namespace Ideate.ModelessAddinSolution.Resources.Dialogs
{
    /// <summary>
    /// Interaction logic for ModalDlg.xaml
    /// </summary>
    public partial class ModalDlg : Window
    {
        public ModalDlg()
        {
            InitializeComponent();

            // set the title to have an instance count.
            this.Title = this.Title + " " + ++_sModalDlgCnt;
        }

        private static int _sModalDlgCnt = 0;
    }
}
